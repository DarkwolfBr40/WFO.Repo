import xbmcaddon

MainBase = 'http://pastebin.com/raw/q6A2eYpf'
addon = xbmcaddon.Addon('plugin.video.Werewolf Filmes Online 1.0')